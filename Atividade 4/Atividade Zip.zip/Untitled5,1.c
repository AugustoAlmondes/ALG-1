#include<stdio.h>
int main(){
    float D, R, T, V, T2;

    printf("Digite o valor do deposito: ");
    scanf("%f",&D);

    printf("Digite o valor da taxa: ");
    scanf("%f",&T);

    T2= T/100;
    R = D * T2;
    V = R + D;

    printf("O valor total eh: %2f ", V);
    return 0;
}
