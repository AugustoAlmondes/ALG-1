#include<stdio.h>

int main(){

int N, N1, N2, N3, N4, N5;

printf("Digite o numero com 5 digitos:  \n");
    scanf("%i",&N);

    N1 = N / 10000;

    N2 = ((N%10000)/1000);
    N3 = (((N%10000)%1000)/100);
    N4 = ((((N%10000)%1000)%100)/10);
    N5 = (((((N%10000)%1000)%100)%10)/1);

    printf(" \n Dezena de milhar: %i \n",N1 );
          if  (N1%2==0){
        printf("\n O numero eh par \n");
          } else {
        printf("\n O numero eh impar \n");
}
    printf(" \n Unidade de milhar: %i \n",N2 );
        if  (N2%2==0){
        printf("\n O numero eh par \n");
          } else {
        printf("\n O numero eh impar \n");
}
    printf(" \n Centena: %i \n",N3 );
        if  (N3%2==0){
        printf("\n O numero eh par \n");
          } else {
        printf("\n O numero eh impar \n");
}
    printf(" \n Dezena: %i \n",N4 );
        if  (N4%2==0){
        printf("\n O numero eh par \n");
          } else {
        printf("\n O numero eh impar \n");
}
    printf(" \n Unidade: %i \n",N5 );
            if  (N5%2==0){
        printf("\n O numero eh par \n");
          } else {
        printf("\n O numero eh impar \n");
}






return 0;
}
