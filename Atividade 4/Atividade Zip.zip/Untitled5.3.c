#include<stdio.h>

void main(){

float V, L;

printf("Digite o valor do produto: ");
    scanf("%f",&V);


        if(V < 20){
          printf("O valor do lucro eh: %f \n", V * 0.45);

   } else {
          printf("O valor do lucro eh: %f \n", V * 0.30);
   }
return 0;
}
