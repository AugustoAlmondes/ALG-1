#include <stdio.h>

int main(){

float S, D, V;

printf("Digite o valor do salario: ");
scanf("%f",&S);

    if (S > 600&& S<=1200){
        D = S * 0.20;
        V = S-D;
        printf("O valor do desconte eh: %f \n",D);
        printf("O valor do salario eh de: %f \n",V);
  } else{
        if (S > 1200 && S<=2000){
         D = S * 0.25;
            V = S-D;
            printf("O valor do desconte eh: %f \n",D);
            printf("O valor do salario eh de: %f \n",V);
      } else {
        if (S > 2000){
        D = S * 0.30;
        V = S-D;
        printf("O valor do desconte eh: %f \n",D);
        printf("O valor do salario eh de: %f \n",V);
} else{
    printf("O valor eh isento \n");
}
}
}
return 0;
}
