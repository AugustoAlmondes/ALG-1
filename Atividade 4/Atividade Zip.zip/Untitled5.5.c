
#include<stdio.h>

int main(){

int N, I, Nd, Co, S;

printf("Digite um dos seguinte valores para escolher o seu destino \n");

printf("Norte = 1 \n");

printf("Nordeste = 2 \n");

printf("CentroOeste = 3 \n");

printf("Sul = 4 \n");

 printf("\n Digite o seu destino (Norte, Nordeste< CentroOeste ou Sul):  ");
    scanf("%i",&N);

       printf(" \n Digite 1 para passagem de ida \n");
        printf(" \n Digite 2 para passagem de ida e volta \n");


    switch (N){

        case 1:
        printf(" \n Digite o tipo da passagem: ");
            scanf("%i",&I);

            if (I == 1){
                printf("Voce pagara: 300.00 \n");
                    } else {
                         if (I == 2){
                    printf("Voce pagara: 900.00 \n");
                    } else {
                        printf("Valor nao encontrado");
                    }
                    }
            break;

              case 2:
        printf("\n Digite o tipo da passagem: ");
            scanf("%i",&I);

            if (I == 1){
                printf("Voce pagara: 350.00 \n");
                    } else {
                         if (I == 2){
                    printf("Voce pagara: 650.00 \n");
                    }   {
                        printf("Valor nao encontrado");
                    }
                    }
            break;

            case 3:
        printf("\n Digite o tipo da passagem: ");
            scanf("%i",&I);

            if (I == 1){
                printf("Voce pagara: 350.00 \n");
                    } else {
                         if (I == 2){
                    printf("Voce pagara: 600.00 \n");
                    } else {
                        printf("\n Valor nao encontrado");
                    }
                    }
            break;

            case 4:
        printf("\n Digite o tipo da passagem: ");
            scanf("%i",&I);

            if (I == 1){
                printf("Voce pagara: 300.00 \n");
                    } else {
                         if (I == 2){
                    printf("Voce pagara: 550.00 \n");
                    }  else {
                        printf("\n Valor nao encontrado");
                    }
                    }
            break;
            default: printf ("\n\nO repita o processo novamente.\n");

    }

return 0;
}
