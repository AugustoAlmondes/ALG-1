#include<stdio.h>

int main(){
int Q, D;
float V;

printf("Digite a quantidade de ma�as: \n");
    scanf("%i",&Q);

    D = 12;
if(Q<D){
    printf("O valor total eh %f \n",V ,V = Q*1.30);
} else
    printf("O valor total eh %f \n",V ,V = Q*1);
    return 0;
}
