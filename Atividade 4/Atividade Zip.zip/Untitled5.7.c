#include<stdio.h>

int main(){

    int I1, I2, I3, I4, Hv, Hn, Mv, Mn, S, P;

printf("Digite a idade do primeiro Homem: ");
    scanf("%i",&I1);
printf("Digite a idade do segundo Homem: ");
    scanf("%i",&I2);
printf("Digite a idade da primeira mulher: ");
    scanf("%i",&I3);
printf("Digite a idade da segunda mulher: ");
    scanf("%i",&I4);

    if (I1 > I2){
        printf("A idade do homem mais velho eh: %i \n",I1);
        Hv = I1;
        Hn = I2;
    } else {
        printf("A idade do homem mais velho eh: %i \n",I2);
        Hv = I2;
        Hn = I1;
    }
         if (I3 > I4){
        printf("\n A idade da mulher mais velha eh: %i \n",I3);
        Mv = I3;
        Mn = I4;
    } else {
        printf("\n A idade da mulher mais velha eh: %i \n",I4);
        Mv = I4;
        Mn = I3;
    }
            S = Hv + Mn;
    printf("\n A soma das idades eh: %i \n", S);

            P = Hn + Mv;
     printf("\n O produto das idades eh: %i \n", P);

return 0;
}
