#include<stdio.h>

int main(){

int N1, N2, N3, N4, M;

printf("\n Digite o primeiro valor:  \n");
    scanf("%i", &N1);
printf("\n Digite o segundo valor:  \n");
    scanf("%i", &N2);
printf("\n Digite o terceiro valor: \n");
    scanf("%i", &N3);
printf("\n Digite o quarto valor:  \n");
    scanf("%i", &N4);

        M = (N1*1)+(N2*2)+(N3*3)+(N4*4)+4;
        M = M/10;

    printf("O valor da media eh: %i \n");
    return 0;
}
