#include<Stdio.h>

int main(){

int v1;
int contador, valor;

    for(contador = 5; contador <= 101; contador= contador +5){

        printf("%i \n",contador);
    }
return 0;
}
